/*******************************************************************************
/* ODBCSQL: a sample program that implements an ODBC command line interpreter.
/*
/* USAGE:   ODBCSQL DSN=<dsn name>   or
/*          ODBCSQL FILEDSN=<file dsn> or
/*          ODBCSQL DRIVER={driver name}
/*
/*
/* Copyright(c)  Microsoft Corporation.   This is a WDAC sample program and
/* is not suitable for use in production environments.
/*
/******************************************************************************/
/* Modules:
/*      Main                Main driver loop, executes queries.
/*      DisplayResults      Display the results of the query if any
/*      AllocateBindings    Bind column data
/*      DisplayTitles       Print column titles
/*      SetConsole          Set console display mode
/*      HandleError         Show ODBC error messages
/******************************************************************************/

#include <windows.h>
#include <sql.h>
#include <sqlext.h>
#include <stdio.h>
#include <conio.h>
#include <tchar.h>
#include <stdlib.h>
#include <sal.h>
#include <iostream>
#include <string>
using namespace std;

WCHAR* myValue;
WCHAR* ReturnResults(HSTMT       hStmt,
	SQLSMALLINT cCols);
/*******************************************/
/* Macro to call ODBC functions and        */
/* report an error on failure.             */
/* Takes handle, handle type, and stmt     */
/*******************************************/



#define TRYODBC(h, ht, x)   {   RETCODE rc = x;\
                                if (rc != SQL_SUCCESS) \
                                { \
                                    HandleDiagnosticRecord (h, ht, rc); \
                                } \
                                if (rc == SQL_ERROR) \
                                { \
                                    fwprintf(stderr, L"Error in " L#x L"\n"); \
                                    goto Exit;  \
                                }  \
                            }
/******************************************/
/* Structure to store information about   */
/* a column.
/******************************************/

typedef struct STR_BINDING {
	SQLSMALLINT         cDisplaySize;           /* size to display  */
	WCHAR* wszBuffer;             /* display buffer   */
	SQLLEN              indPtr;                 /* size or null     */
	BOOL                fChar;                  /* character col?   */
	struct STR_BINDING* sNext;                 /* linked list      */
} BINDING;



/******************************************/
/* Forward references                     */
/******************************************/

void HandleDiagnosticRecord(SQLHANDLE      hHandle,
	SQLSMALLINT    hType,
	RETCODE        RetCode);

void DisplayResults(HSTMT       hStmt,
	SQLSMALLINT cCols);

void AllocateBindings(HSTMT         hStmt,
	SQLSMALLINT   cCols,
	BINDING** ppBinding,
	SQLSMALLINT* pDisplay);


void DisplayTitles(HSTMT    hStmt,
	DWORD    cDisplaySize,
	BINDING* pBinding);

void SetConsole(DWORD   cDisplaySize,
	BOOL    fInvert);

/*****************************************/
/* Some constants                        */
/*****************************************/


#define DISPLAY_MAX 50          // Arbitrary limit on column width to display
#define DISPLAY_FORMAT_EXTRA 3  // Per column extra display bytes (| <data> )
#define DISPLAY_FORMAT      L"%c %*.*s "
#define DISPLAY_FORMAT_C    L"%c %-*.*s "
#define NULL_SIZE           6   // <NULL>
#define SQL_QUERY_SIZE      1000 // Max. Num characters for SQL Query passed in.

#define PIPE                L'|'

SHORT   gHeight = 80;       // Users screen height

string convert2(WCHAR* txt)
{
	wstring ws(txt);
	string str(ws.begin(), ws.end());
	return str;
}

void convert(string szSource, WCHAR* wszDest)
{
	const size_t WCHARBUF = 100;
	MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, szSource.c_str(), -1, wszDest, WCHARBUF);
}


void ExecuteSQLStmt(WCHAR* wszInput, SQLHSTMT& hStmt)
{

	RETCODE     RetCode;
	SQLSMALLINT sNumResults;


	RetCode = SQLExecDirect(hStmt, wszInput, SQL_NTS);

	switch (RetCode)
	{
	case SQL_SUCCESS_WITH_INFO:
	{
		HandleDiagnosticRecord(hStmt, SQL_HANDLE_STMT, RetCode);
		// fall through
	}
	case SQL_SUCCESS:
	{
		// If this is a row-returning query, display
		// results
		TRYODBC(hStmt,
			SQL_HANDLE_STMT,
			SQLNumResultCols(hStmt, &sNumResults));

		if (sNumResults > 0)
		{
			DisplayResults(hStmt, sNumResults);
		}
		else
		{
			SQLLEN cRowCount;

			TRYODBC(hStmt,
				SQL_HANDLE_STMT,
				SQLRowCount(hStmt, &cRowCount));

			if (cRowCount >= 0)
			{
				wprintf(L"%Id %s affected\n",
					cRowCount,
					cRowCount == 1 ? L"row" : L"rows");
			}
		}
		break;
	}

	case SQL_ERROR:
	{
		HandleDiagnosticRecord(hStmt, SQL_HANDLE_STMT, RetCode);
		break;
	}

	default:
		fwprintf(stderr, L"Unexpected return code %hd!\n", RetCode);

	}
	TRYODBC(hStmt,
		SQL_HANDLE_STMT,
		SQLFreeStmt(hStmt, SQL_CLOSE));

Exit:
	;
}

WCHAR* myExecuteSQLStmt(WCHAR* wszInput, SQLHSTMT& hStmt)
{

	RETCODE     RetCode;
	SQLSMALLINT sNumResults;


	RetCode = SQLExecDirect(hStmt, wszInput, SQL_NTS);

	switch (RetCode)
	{
	case SQL_SUCCESS_WITH_INFO:
	{
		HandleDiagnosticRecord(hStmt, SQL_HANDLE_STMT, RetCode);
		// fall through
	}
	case SQL_SUCCESS:
	{
		// If this is a row-returning query, display
		// results
		TRYODBC(hStmt,
			SQL_HANDLE_STMT,
			SQLNumResultCols(hStmt, &sNumResults));

		if (sNumResults > 0)
		{
			return ReturnResults(hStmt, sNumResults);
		}
		else
		{
			SQLLEN cRowCount;

			TRYODBC(hStmt,
				SQL_HANDLE_STMT,
				SQLRowCount(hStmt, &cRowCount));

			if (cRowCount >= 0)
			{
				wprintf(L"%Id %s affected\n",
					cRowCount,
					cRowCount == 1 ? L"row" : L"rows");
			}
		}
		break;
	}

	case SQL_ERROR:
	{
		HandleDiagnosticRecord(hStmt, SQL_HANDLE_STMT, RetCode);
		break;
	}

	default:
		fwprintf(stderr, L"Unexpected return code %hd!\n", RetCode);

	}
	TRYODBC(hStmt,
		SQL_HANDLE_STMT,
		SQLFreeStmt(hStmt, SQL_CLOSE));

Exit:
	return NULL;
}

int __cdecl wmain(int argc, _In_reads_(argc) WCHAR** argv)
{
	SQLHENV     hEnv = NULL;
	SQLHDBC     hDbc = NULL;
	SQLHSTMT    hStmt = NULL;
	WCHAR* pwszConnStr = NULL;
	WCHAR       wszInput[SQL_QUERY_SIZE];

	//Students should modifiy the following variables
	string EMP_ID = "";
	string FNAME = "";
	string MID_NAME = "";
	string LNAME = "";
	string E_CITY = "";
	string E_COUNTRY = "";
	string E_HOUSE_NO = "";
	string SALARY = "";
	string START_DATE = "";
	string National_ID = "";
	string C_FNAME = "";
	string C_MIDNAME = "";
	string C_LNAME = "";
	string C_DOB = "";
	string driving_License = "";
	string C_ADDRESS = "";
	string RENT_ID = "";
	string RES_ID = "";
	string CH_FNAME = "";
	string CHAUFFEUR_ID = "";
	string CH_MIDNAME = "";
	string CH_LNAME = "";
	string CH_DOB = "";
	string Ch_COUNTRY = "";
	string Ch_CITY = "";
	string Ch_HOUSE_NO = "";
	string PRICE_HOUR = "";
	string PICKUP_DATE = "";
	string RETURN_DATE = "";
	string RESERVE_DATE = "";
	string R_CITY = "";
	string R_STREET = "";
	string Status_ID = "";
	string CAR_ID = "";
	string MILEAGE = "";
	string PLATE_NO = "";
	string carmileage = "";
	string CAR_MODEL = "";
	string insurance = "";
	string FUEL_TYPE = "";
	string Condition_ID = "";
	string condition_ID = "";
	string TAX_AMOUNT = "";
	string FINAL_PAY_D = "";
	string DOWN_PAY_D = "";
	string REFUND = "";
	string DAMAGE_COST = "";
	string DOWN_PAY = "";
	string chauffeur_bill = "";
	string Method_ID = "";
	//string ="";
	//string ="";
	// Allocate an environment

	if (SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &hEnv) == SQL_ERROR)
	{
		fwprintf(stderr, L"Unable to allocate an environment handle\n");
		exit(-1);
	}

	// Register this as an application that expects 3.x behavior,
	// you must register something if you use AllocHandle

	TRYODBC(hEnv,
		SQL_HANDLE_ENV,
		SQLSetEnvAttr(hEnv,
			SQL_ATTR_ODBC_VERSION,
			(SQLPOINTER)SQL_OV_ODBC3,
			0));

	// Allocate a connection
	TRYODBC(hEnv,
		SQL_HANDLE_ENV,
		SQLAllocHandle(SQL_HANDLE_DBC, hEnv, &hDbc));

	if (argc > 1)
	{
		pwszConnStr = *++argv;
	}
	else
	{
		pwszConnStr = L"";
	}


	//Student must insert his/her connection string
	pwszConnStr = L"workstation id=AutoLunatic.mssql.somee.com;packet size=4096;user id=AN234463_SQLLogin_1;pwd=swiuy4rafm;data source=AutoLunatic.mssql.somee.com;persist security info=False;initial catalog=AutoLunatic";
	//pwszConnStr = L"Driver={SQL Server};Server=localhost\\SQLEXPRESS;Database=Company;Trusted_Connection=Yes;";

	// Connect to the driver.  Use the connection string if supplied
	// on the input, otherwise let the driver manager prompt for input.

	TRYODBC(hDbc,
		SQL_HANDLE_DBC,
		SQLDriverConnect(hDbc,
			GetDesktopWindow(),
			pwszConnStr,
			SQL_NTS,
			NULL,
			0,
			NULL,
			SQL_DRIVER_COMPLETE));

	fwprintf(stderr, L"Connected!\n");

	TRYODBC(hDbc,
		SQL_HANDLE_DBC,
		SQLAllocHandle(SQL_HANDLE_STMT, hDbc, &hStmt));


	//Student Code
	int choice = 10;

	while (choice != -1)
	{
		int employeeChoice = 10;
		int CustomerChoice = 10;
		int ChaufferChoice = 10;
		int reservationChoice = 10;
		int vehicleChoice = 10;
		int rentChoice = 10;
		cout << "==============================" << endl;
		cout << "=         Main Menu          =" << endl;
		cout << "==============================" << endl;
		cout << "1: Employee Menu" << endl;
		cout << "2: Customer Menu" << endl;
		cout << "3: Chauffeur Menu" << endl;
		cout << "4: Reservation Menu" << endl;
		cout << "5: Vehicles Menu" << endl;
		cout << "6: Rent Menu" << endl;
		cout << "-1: Exit" << endl;
		cout << "Choice: ";
		cin >> choice;
		switch (choice)
		{
		case 1:
			while (employeeChoice != -1)
			{
				cout << "==============================" << endl;
				cout << "=       Employee Menu        =" << endl;
				cout << "==============================" << endl;
				cout << "1: Show All Employee" << endl;
				cout << "2: Insert new Employee" << endl;
				cout << "3: Delete current Employee" << endl;
				cout << "4: Update current Employee" << endl;
				cout << "-1: Back to the main menu" << endl;
				cout << "Choice: ";
				cin >> employeeChoice;
				switch (employeeChoice)
				{
				case 1:
					cout << "==============================" << endl;
					convert("Select * from Employee", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					//cout << "My value = " << myValue << endl;
					break;
				case 2:
					cout << "==============================" << endl;
					cout << "Enter employee ID: ";
					cin >> EMP_ID;
					cout << "Enter first name: ";
					cin >> FNAME;
					cout << "Enter mid name: ";
					cin >> MID_NAME;
					cout << "Enter last name";
					cin >> LNAME;
					cout << "Enter the city";
					cin >> E_CITY;
					cout << "Enter the Country";
					cin >> E_COUNTRY;
					cout << "Enter the house_NO";
					cin >> E_HOUSE_NO;
					cout << "Enter the Salary";
					cin >> SALARY;
					cout << "Enter the Start date";
					cin >> START_DATE;
					convert("insert into Employee values(" + EMP_ID + "','" + FNAME + "','" + MID_NAME + "','" + LNAME + "','" + E_CITY + "','" + E_COUNTRY + "','" + E_HOUSE_NO + "','" + SALARY + "','" + START_DATE + ")", wszInput);
					//cout<< "insert into students values(" + EMP_ID + ",'" + stdName + "','" + stdCollege + "')" <<endl;
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 3:
					cout << "==============================" << endl;
					cout << "Enter Employee ID to delete: ";
					cin >> EMP_ID;
					convert("delete from Employee where id = " + EMP_ID, wszInput);
					cout << "delete from Employee where id = " + EMP_ID << endl;
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 4:
					cout << "==============================" << endl;
					cout << "Enter Employee ID to update: ";
					cin >> EMP_ID;
					cout << "Enter new first name: ";
					cin >> FNAME;
					cout << "Enter new mid name: ";
					cin >> MID_NAME;
					cout << "Enter new last name";
					cin >> LNAME;
					cout << "Enter new the city";
					cin >> E_CITY;
					cout << "Enter new the Country";
					cin >> E_COUNTRY;
					cout << "Enter new the house_NO";
					cin >> E_HOUSE_NO;
					cout << "Enter new the Salary";
					cin >> SALARY;
					cout << "Enter new the Start date";
					cin >> START_DATE;
					convert("update Employee set FNAME = '" + FNAME + " ', MID_NAME = '" + MID_NAME + " ', LNAME = '" + LNAME + " ', E_CITY = '" + E_CITY + " ', E_COUNTRY = '" + E_COUNTRY + " ', E_HOUSE_NO = '" + E_HOUSE_NO + " ', Salary = '" + SALARY + "' where EMP_ID = " + EMP_ID, wszInput);
					//cout << "update Students set student_name = '" + stdName + " ', college_name = '" + stdCollege + "' where id = " + EMP_ID << endl;
					//ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				}
			}
			break;
		case 2:
			while (CustomerChoice != -1)
			{
				cout << "==============================" << endl;
				cout << "=       Customer Menu        = " << endl;
				cout << "==============================" << endl;
				cout << "1: Show All Customer" << endl;
				cout << "2: Insert new Customer" << endl;
				cout << "3: Delete current Customer" << endl;
				cout << "4: Update current Customer" << endl;
				cout << "-1: Back to the main menu" << endl;
				cout << "Choice: ";
				cin >> CustomerChoice;
				switch (CustomerChoice)
				{
				case 1:
					cout << "==============================" << endl;
					convert("Select * from Customer", wszInput);
					//myValue = myExecuteSQLStmt(wszInput, hStmt);
					ExecuteSQLStmt(wszInput, hStmt);
					//cout <<"My value = " << convert2(myValue) << endl;
					break;
				case 2:
					cout << "==============================" << endl;
					cout << "Enter National ID: ";
					cin >> National_ID;
					cout << "Enter Customer first name: ";
					cin >> C_FNAME;
					cout << "Enter Customer second name: ";
					cin >> C_MIDNAME;
					cout << "Enter Customer last name: ";
					cin >> C_LNAME;
					cout << "Enter Date of birth: ";
					cin >> C_DOB;
					cout << "Enter driving license: ";
					cin >> driving_License;
					cout << "Enter customer Address: ";
					cin >> C_ADDRESS;
					convert("insert into customer values(" + National_ID + ",'" + C_FNAME + "','" + C_MIDNAME + "','" + C_LNAME + "','" + C_DOB + "','" + driving_License + "','" + C_ADDRESS + ")", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 3:
					cout << "==============================" << endl;
					cout << "Enter National ID to delete: ";
					cin >> National_ID;
					convert("delete from Customer where National_ID = '" + National_ID + "'", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 4:
					cout << "==============================" << endl;
					cout << "Enter National ID to update: ";
					cin >> National_ID;
					cout << "Enter the New Driving licence: ";
					cin >> driving_License;
					convert("update customer set driving_license = " + driving_License + " where name = '" + National_ID + "'", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				}
			}
		case 3:
			while (ChaufferChoice != -1)
			{
				cout << "==============================" << endl;
				cout << "=       Chauffeur Menu        =" << endl;
				cout << "==============================" << endl;
				cout << "1: Show All Chauffeurs" << endl;
				cout << "2: Insert new Chauffeur" << endl;
				cout << "3: Delete current Chauffeur" << endl;
				cout << "4: Update current Chauffeur" << endl;
				cout << "-1: Back to the main menu" << endl;
				cout << "Choice: ";
				cin >> ChaufferChoice;
				switch (ChaufferChoice)
				{
				case 1:
					cout << "==============================" << endl;
					convert("Select * from Chauffeur", wszInput);
					//myValue = myExecuteSQLStmt(wszInput, hStmt);
					ExecuteSQLStmt(wszInput, hStmt);
					//cout <<"My value = " << convert2(myValue) << endl;
					break;
				case 2:
					cout << "==============================" << endl;
					cout << "Enter Chauffeur ID: ";
					cin >> CHAUFFEUR_ID;
					cout << "Enter Chauffeur first name: ";
					cin >> CH_FNAME;
					cout << "Enter Chauffeur second name: ";
					cin >> CH_MIDNAME;
					cout << "Enter Chauffeur last name: ";
					cin >> CH_LNAME;
					cout << "Enter Chauffeur Date of birth: ";
					cin >> CH_DOB;
					cout << "Enter Chauffeur country: ";
					cin >> Ch_COUNTRY;
					cout << "Enter Chauffeur city: ";
					cin >> Ch_CITY;
					cout << "Enter Chauffeur house number: ";
					cin >> Ch_HOUSE_NO;
					cout << "Enter Chauffeur price per hour: ";
					cin >> PRICE_HOUR;
					convert("insert into Chauffeur values(" + CHAUFFEUR_ID + "','" + CH_FNAME + "','" + CH_MIDNAME + "','" + CH_LNAME + "','" + CH_DOB + "','" + Ch_COUNTRY + "','" + Ch_CITY + "','" + Ch_HOUSE_NO + "','" + PRICE_HOUR + ")", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 3:
					cout << "==============================" << endl;
					cout << "Enter Chauffeur ID to delete: ";
					cin >> CHAUFFEUR_ID;
					convert("delete from Chauffeur where CHAUFFEUR_ID = '" + CHAUFFEUR_ID + "'", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 4:
					cout << "==============================" << endl;
					cout << "Enter NEW Chauffeur ID: ";
					cin >> CHAUFFEUR_ID;
					cout << "Enter Chauffeur NEW first name: ";
					cin >> CH_FNAME;
					cout << "Enter Chauffeur NEW second name: ";
					cin >> CH_MIDNAME;
					cout << "Enter Chauffeur NEW last name: ";
					cin >> CH_LNAME;
					cout << "Enter Chauffeur NEW Date of birth: ";
					cin >> CH_DOB;
					cout << "Enter Chauffeur NEW country: ";
					cin >> Ch_COUNTRY;
					cout << "Enter Chauffeur NEW city: ";
					cin >> Ch_CITY;
					cout << "Enter Chauffeur NEW house number: ";
					cin >> Ch_HOUSE_NO;
					cout << "Enter Chauffeur NEW price per hour: ";
					cin >> PRICE_HOUR;
					convert("update Chauffeur set CH_FNAME = '" + CH_FNAME + " ', CH_MIDNAME = '" + CH_MIDNAME + " ', CH_LNAME = '" + CH_LNAME + " ', CH_DOB = '" + CH_DOB + " ', CH_COUNTRY = '" + Ch_COUNTRY + " ', CH_CITY = '" + Ch_CITY + " ', CH_HOUSE_NO = '" + Ch_HOUSE_NO + " ', PRICEHOUR = '" + PRICE_HOUR + "' where CH_ID = " + CHAUFFEUR_ID, wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				}
			}
			break;
		case 4:
			while (reservationChoice != -1)
			{
				cout << "==============================" << endl;
				cout << "=       Reservation Menu        =" << endl;
				cout << "==============================" << endl;
				cout << "1: Show All Reservations" << endl;
				cout << "2: Insert new Reservation" << endl;
				cout << "3: Delete current Reservation" << endl;
				cout << "4: Update current Reservation" << endl;
				cout << "-1: Back to the main menu" << endl;
				cout << "Choice: ";
				cin >> reservationChoice;
				switch (reservationChoice)
				{
				case 1:
					cout << "==============================" << endl;
					convert("Select * from Reservation", wszInput);
					//myValue = myExecuteSQLStmt(wszInput, hStmt);
					ExecuteSQLStmt(wszInput, hStmt);
					//cout <<"My value = " << convert2(myValue) << endl;
					break;
				case 2:
					cout << "==============================" << endl;
					cout << "Enter Reservation ID: ";
					cin >> RES_ID;
					cout << "Enter  pickup date ";
					cin >> PICKUP_DATE;
					cout << "Enter return date: ";
					cin >> RETURN_DATE;
					cout << "Enter  reserve date: ";
					cin >> RESERVE_DATE;
					cout << "Enter Reservation city: ";
					cin >> R_CITY;
					cout << "Enter Reservation street: ";
					cin >> R_STREET;
					cout << "Enter employee ID: ";
					cin >> EMP_ID;
					cout << "Enter CHAUFFER ID: ";
					cin >> CHAUFFEUR_ID;
					cout << "Enter Status_ID: ";
					cin >> Status_ID;
					convert("insert into Reservation values('" + RES_ID + "','" + PICKUP_DATE + "'," + RETURN_DATE + "'" + RESERVE_DATE + "','" + R_CITY + "', '" + R_STREET + "','" + PRICE_HOUR + EMP_ID + "','" + CHAUFFEUR_ID + "','" + Status_ID + ")", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 3:
					cout << "==============================" << endl;
					cout << "Enter Reservation ID to delete: ";
					cin >> RES_ID;
					convert("delete from Reservation where RES_ID = '" + RES_ID + "'", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 4:
					cout << "==============================" << endl;
					cout << "Enter Reservation ID to update: ";
					cin >> RES_ID;
					cout << "Enter Reservation pickup date: ";
					cin >> PICKUP_DATE;
					cout << "Enter Reservation return date: ";
					cin >> RETURN_DATE;
					cout << "Enter Reservation reserve date: ";
					cin >> RESERVE_DATE;
					cout << "Enter the city name: ";
					cin >> R_CITY;
					cout << "Enter the country name: ";
					cin >> R_STREET;
					cout << "Enter new employee ID: ";
					cin >> EMP_ID;
					cout << "Enter new CHAUFFER ID: ";
					cin >> CHAUFFEUR_ID;
					cout << "Enter new Status_ID: ";
					cin >> Status_ID;
					convert("update Reservation set Pickup_date = '" + PICKUP_DATE + " ', RETURN_DATE = '" + RETURN_DATE + " ', RESERVE_DATE = '" + RESERVE_DATE + " ', R_CITY = '" + R_CITY + " ', R_STREET = '" + R_STREET + "', emp_id='" + EMP_ID + "', chaufferID= '" + CHAUFFEUR_ID + "',Status_id='" + Status_ID + "' where RES_ID = " + RES_ID, wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				}
			}
			break;
		case 5:
			while (vehicleChoice != -1)
			{
				cout << "==============================" << endl;
				cout << "=       Vehicle Menu        =" << endl;
				cout << "==============================" << endl;
				cout << "1: Show All Vehicles" << endl;
				cout << "2: Insert new Vehicle" << endl;
				cout << "3: Delete current Vehicle" << endl;
				cout << "4: Update current Vehicle" << endl;
				cout << "-1: Back to the main menu" << endl;
				cout << "Choice: ";
				cin >> vehicleChoice;
				switch (vehicleChoice)
				{
				case 1:
					cout << "==============================" << endl;
					convert("Select * from Vehicle", wszInput);
					//myValue = myExecuteSQLStmt(wszInput, hStmt);
					ExecuteSQLStmt(wszInput, hStmt);
					//cout <<"My value = " << convert2(myValue) << endl;
					break;
				case 2:
					cout << "==============================" << endl;
					cout << "Enter Vehicle ID: ";
					cin >> CAR_ID;
					cout << "Enter Vehicle mileage ";
					cin >> MILEAGE;
					cout << "Enter Vehicle plate number: ";
					cin >> PLATE_NO;
					cout << "Enter Vehicle car model: ";
					cin >> CAR_MODEL;
					cout << "Enter Vehicle insurance: ";
					cin >> insurance;
					cout << "Enter Vehicle fuel type: ";
					cin >> FUEL_TYPE;
					cout << "Enter condition: ";
					cin >> condition_ID;
					cout << "Enter RES_ID: ";
					cin >> RES_ID;
					convert("insert into Vehicle_ values('" + CAR_ID + "','" + MILEAGE + "'," + PLATE_NO + "'" + CAR_MODEL + "','" + insurance + "', '" + FUEL_TYPE + "', '" + condition_ID + "', '" + RES_ID + "', ')", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 3:
					cout << "==============================" << endl;
					cout << "Enter Vehicle ID to delete: ";
					cin >> CAR_ID;
					convert("delete from Vehicle_ where CAR_ID = '" + CAR_ID + "'", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 4:
					cout << "==============================" << endl;
					cout << "Enter Vehicle ID to update: ";
					cin >> CAR_ID;
					cout << "Enter Vehicle mileage: ";
					cin >> MILEAGE;
					cout << "Enter Vehicle plate number: ";
					cin >> PLATE_NO;
					cout << "Enter Vehicle car model: ";
					cin >> CAR_MODEL;
					cout << "Enter Vehicle insurance: ";
					cin >> insurance;
					cout << "Enter Vehicle fuel type: ";
					cin >> FUEL_TYPE;
					cout << "Enter Condition_ID: ";
					cin >> Condition_ID;
					cout << "Enter RES_ID: ";
					cin >> RES_ID;
					convert("update Vehicle_ set MILEAGE = '" + MILEAGE + "', PLATE_NO = '" + PLATE_NO + " ', CAR_MODEL = '" + CAR_MODEL + " ', insurance = '" + insurance + "' ', FUEL_TYPE = '" + FUEL_TYPE + "' where CAR_ID = " + CAR_ID + ")", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				}
			}
			break;
		case 6:
			while (rentChoice != -1)
			{
				cout << "==============================" << endl;
				cout << "=       Rent Menu        =" << endl;
				cout << "==============================" << endl;
				cout << "1: Show All Rent" << endl;
				cout << "2: Insert new Rent" << endl;
				cout << "3: Delete current Rent" << endl;
				cout << "4: Update current Rent" << endl;
				cout << "-1: Back to the main menu" << endl;
				cout << "Choice: ";
				cin >> rentChoice;
				switch (rentChoice)
				{
				case 1:
					cout << "==============================" << endl;
					convert("Select * from Rent", wszInput);
					//myValue = myExecuteSQLStmt(wszInput, hStmt);
					ExecuteSQLStmt(wszInput, hStmt);
					//cout <<"My value = " << convert2(myValue) << endl;
					break;
				case 2:
					cout << "==============================" << endl;
					cout << "Enter Rent ID: ";
					cin >> RENT_ID;
					cout << "Enter Rent tax amount ";
					cin >> TAX_AMOUNT;
					cout << "Enter Rent final pay date: ";
					cin >> FINAL_PAY_D;
					cout << "Enter Rent down pay date: ";
					cin >> DOWN_PAY_D;
					cout << "Enter Rent refund: ";
					cin >> REFUND;
					cout << "Enter Rent damage cost: ";
					cin >> DAMAGE_COST;
					cout << "Enter Rent down pay: ";
					cin >> DOWN_PAY;
					cout << "Enter Rent chauffeur bill: ";
					cin >> chauffeur_bill;
					cout << "Enter CAR_ID: ";
					cin >> CAR_ID;
					cout << "Enter RES_ID: ";
					cin >> RES_ID;
					cout << "Enter CHAUFFEUR ID: ";
					cin >> CHAUFFEUR_ID;
					cout << "Enter Method_ID: ";
					cin >> Method_ID;
					convert("insert into Rent values('" + RENT_ID + "','" + TAX_AMOUNT + "'," + FINAL_PAY_D + "'" + DOWN_PAY_D + "','" + REFUND + "', '" + DAMAGE_COST + "', '" + DOWN_PAY + "', '" + chauffeur_bill + "', '" + CAR_ID + "', '" + RES_ID + "', '" + CHAUFFEUR_ID + "', '" + Method_ID + "',)", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 3:
					cout << "==============================" << endl;
					cout << "Enter Rent ID to delete: ";
					cin >> RENT_ID;
					convert("delete from Rent where RENT_ID = '" + RENT_ID + "'", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				case 4:
					cout << "==============================" << endl;
					cout << "Enter Rent ID to update: ";
					cin >> RENT_ID;
					cout << "Enter Rent tax amount: ";
					cin >> TAX_AMOUNT;
					cout << "Enter Rent final pay date: ";
					cin >> FINAL_PAY_D;
					cout << "Enter Rent down pay date: ";
					cin >> DOWN_PAY_D;
					cout << "Enter Rent refund: ";
					cin >> REFUND;
					cout << "Enter Rent damage cost: ";
					cin >> DAMAGE_COST;
					cout << "Enter Rent chauffeur bill: ";
					cin >> chauffeur_bill;
					convert("update Rent set TAX_AMOUNT = '" + TAX_AMOUNT + " ', FINAL_PAY_D = '" + FINAL_PAY_D + " ', DOWN_PAY_D = '" + DOWN_PAY_D + " ', REFUND = '" + REFUND + "' ', DAMAGE_COST = '" + DAMAGE_COST + "', chauffeur_bill = '" + chauffeur_bill + "' where RENT_ID = " + RENT_ID+")", wszInput);
					ExecuteSQLStmt(wszInput, hStmt);
					cout << "Done" << endl;
					break;
				}
			}
		}

	}

Exit:

	// Free ODBC handles and exit

	if (hStmt)
	{
		SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
	}

	if (hDbc)
	{
		SQLDisconnect(hDbc);
		SQLFreeHandle(SQL_HANDLE_DBC, hDbc);
	}

	if (hEnv)
	{
		SQLFreeHandle(SQL_HANDLE_ENV, hEnv);
	}

	wprintf(L"\nDisconnected.");

	return 0;

}

/************************************************************************
/* DisplayResults: display results of a select query
/*
/* Parameters:
/*      hStmt      ODBC statement handle
/*      cCols      Count of columns
/************************************************************************/

void DisplayResults(HSTMT       hStmt,
	SQLSMALLINT cCols)
{
	BINDING* pFirstBinding, * pThisBinding;
	SQLSMALLINT     cDisplaySize;
	RETCODE         RetCode = SQL_SUCCESS;
	int             iCount = 0;

	// Allocate memory for each column 

	AllocateBindings(hStmt, cCols, &pFirstBinding, &cDisplaySize);

	// Set the display mode and write the titles

	DisplayTitles(hStmt, cDisplaySize + 1, pFirstBinding);


	// Fetch and display the data

	bool fNoData = false;

	do {
		// Fetch a row

		if (iCount++ >= gHeight - 2)
		{
			int     nInputChar;
			bool    fEnterReceived = false;

			while (!fEnterReceived)
			{
				wprintf(L"              ");
				SetConsole(cDisplaySize + 2, TRUE);
				wprintf(L"   Press ENTER to continue, Q to quit (height:%hd)", gHeight);
				SetConsole(cDisplaySize + 2, FALSE);

				nInputChar = _getch();
				wprintf(L"\n");
				if ((nInputChar == 'Q') || (nInputChar == 'q'))
				{
					goto Exit;
				}
				else if ('\r' == nInputChar)
				{
					fEnterReceived = true;
				}
				// else loop back to display prompt again
			}

			iCount = 1;
			DisplayTitles(hStmt, cDisplaySize + 1, pFirstBinding);
		}

		TRYODBC(hStmt, SQL_HANDLE_STMT, RetCode = SQLFetch(hStmt));

		if (RetCode == SQL_NO_DATA_FOUND)
		{
			fNoData = true;
		}
		else
		{

			// Display the data.   Ignore truncations

			for (pThisBinding = pFirstBinding;
				pThisBinding;
				pThisBinding = pThisBinding->sNext)
			{
				if (pThisBinding->indPtr != SQL_NULL_DATA)
				{
					wprintf(pThisBinding->fChar ? DISPLAY_FORMAT_C : DISPLAY_FORMAT,
						PIPE,
						pThisBinding->cDisplaySize,
						pThisBinding->cDisplaySize,
						pThisBinding->wszBuffer);
					myValue = pThisBinding->wszBuffer;
				}
				else
				{
					wprintf(DISPLAY_FORMAT_C,
						PIPE,
						pThisBinding->cDisplaySize,
						pThisBinding->cDisplaySize,
						L"<NULL>");
				}
			}
			wprintf(L" %c\n", PIPE);
		}
	} while (!fNoData);

	SetConsole(cDisplaySize + 2, TRUE);
	wprintf(L"%*.*s", cDisplaySize + 2, cDisplaySize + 2, L" ");
	SetConsole(cDisplaySize + 2, FALSE);
	wprintf(L"\n");

Exit:
	// Clean up the allocated buffers

	while (pFirstBinding)
	{
		pThisBinding = pFirstBinding->sNext;
		free(pFirstBinding->wszBuffer);
		free(pFirstBinding);
		pFirstBinding = pThisBinding;
	}
}

WCHAR* ReturnResults(HSTMT       hStmt,
	SQLSMALLINT cCols)
{
	BINDING* pFirstBinding, * pThisBinding;
	SQLSMALLINT     cDisplaySize;
	RETCODE         RetCode = SQL_SUCCESS;
	int             iCount = 0;
	WCHAR* temp;

	// Allocate memory for each column 

	AllocateBindings(hStmt, cCols, &pFirstBinding, &cDisplaySize);

	// Set the display mode and write the titles

	//DisplayTitles(hStmt, cDisplaySize + 1, pFirstBinding);


	// Fetch and display the data

	bool fNoData = false;

	do {
		// Fetch a row

		if (iCount++ >= gHeight - 2)
		{
			int     nInputChar;
			bool    fEnterReceived = false;

			while (!fEnterReceived)
			{
				//wprintf(L"              ");
				//SetConsole(cDisplaySize + 2, TRUE);
				//wprintf(L"   Press ENTER to continue, Q to quit (height:%hd)", gHeight);
				//SetConsole(cDisplaySize + 2, FALSE);

				//nInputChar = _getch();
				//wprintf(L"\n");
				if ((nInputChar == 'Q') || (nInputChar == 'q'))
				{
					goto Exit;
				}
				else if ('\r' == nInputChar)
				{
					fEnterReceived = true;
				}
				// else loop back to display prompt again
			}

			iCount = 1;
			//DisplayTitles(hStmt, cDisplaySize + 1, pFirstBinding);
		}

		TRYODBC(hStmt, SQL_HANDLE_STMT, RetCode = SQLFetch(hStmt));

		if (RetCode == SQL_NO_DATA_FOUND)
		{
			fNoData = true;
		}
		else
		{

			// Display the data.   Ignore truncations

			for (pThisBinding = pFirstBinding;
				pThisBinding;
				pThisBinding = pThisBinding->sNext)
			{
				if (pThisBinding->indPtr != SQL_NULL_DATA)
				{
					/*wprintf(pThisBinding->fChar ? DISPLAY_FORMAT_C : DISPLAY_FORMAT,
						PIPE,
						pThisBinding->cDisplaySize,
						pThisBinding->cDisplaySize,
						pThisBinding->wszBuffer);*/
					myValue = pThisBinding->wszBuffer;
					temp = pThisBinding->wszBuffer;
					//return pThisBinding->wszBuffer;
				}
				else
				{
					/*wprintf(DISPLAY_FORMAT_C,
						PIPE,
						pThisBinding->cDisplaySize,
						pThisBinding->cDisplaySize,
						L"<NULL>");*/
				}
			}
			//wprintf(L" %c\n", PIPE);
		}
	} while (!fNoData);

	//SetConsole(cDisplaySize + 2, TRUE);
	//wprintf(L"%*.*s", cDisplaySize + 2, cDisplaySize + 2, L" ");
	//SetConsole(cDisplaySize + 2, FALSE);
	//wprintf(L"\n");
	return temp;
Exit:
	// Clean up the allocated buffers

	while (pFirstBinding)
	{
		pThisBinding = pFirstBinding->sNext;
		free(pFirstBinding->wszBuffer);
		free(pFirstBinding);
		pFirstBinding = pThisBinding;
	}
	return temp;
}

/************************************************************************
/* AllocateBindings:  Get column information and allocate bindings
/* for each column.
/*
/* Parameters:
/*      hStmt      Statement handle
/*      cCols       Number of columns in the result set
/*      *lppBinding Binding pointer (returned)
/*      lpDisplay   Display size of one line
/************************************************************************/

void AllocateBindings(HSTMT         hStmt,
	SQLSMALLINT   cCols,
	BINDING** ppBinding,
	SQLSMALLINT* pDisplay)
{
	SQLSMALLINT     iCol;
	BINDING* pThisBinding, * pLastBinding = NULL;
	SQLLEN          cchDisplay, ssType;
	SQLSMALLINT     cchColumnNameLength;

	*pDisplay = 0;

	for (iCol = 1; iCol <= cCols; iCol++)
	{
		pThisBinding = (BINDING*)(malloc(sizeof(BINDING)));
		if (!(pThisBinding))
		{
			fwprintf(stderr, L"Out of memory!\n");
			exit(-100);
		}

		if (iCol == 1)
		{
			*ppBinding = pThisBinding;
		}
		else
		{
			pLastBinding->sNext = pThisBinding;
		}
		pLastBinding = pThisBinding;


		// Figure out the display length of the column (we will
		// bind to char since we are only displaying data, in general
		// you should bind to the appropriate C type if you are going
		// to manipulate data since it is much faster...)

		TRYODBC(hStmt,
			SQL_HANDLE_STMT,
			SQLColAttribute(hStmt,
				iCol,
				SQL_DESC_DISPLAY_SIZE,
				NULL,
				0,
				NULL,
				&cchDisplay));


		// Figure out if this is a character or numeric column; this is
		// used to determine if we want to display the data left- or right-
		// aligned.

		// SQL_DESC_CONCISE_TYPE maps to the 1.x SQL_COLUMN_TYPE. 
		// This is what you must use if you want to work
		// against a 2.x driver.

		TRYODBC(hStmt,
			SQL_HANDLE_STMT,
			SQLColAttribute(hStmt,
				iCol,
				SQL_DESC_CONCISE_TYPE,
				NULL,
				0,
				NULL,
				&ssType));


		pThisBinding->fChar = (ssType == SQL_CHAR ||
			ssType == SQL_VARCHAR ||
			ssType == SQL_LONGVARCHAR);

		pThisBinding->sNext = NULL;

		// Arbitrary limit on display size
		if (cchDisplay > DISPLAY_MAX)
			cchDisplay = DISPLAY_MAX;

		// Allocate a buffer big enough to hold the text representation
		// of the data.  Add one character for the null terminator

		pThisBinding->wszBuffer = (WCHAR*)malloc((cchDisplay + 1) * sizeof(WCHAR));

		if (!(pThisBinding->wszBuffer))
		{
			fwprintf(stderr, L"Out of memory!\n");
			exit(-100);
		}

		// Map this buffer to the driver's buffer.   At Fetch time,
		// the driver will fill in this data.  Note that the size is 
		// count of bytes (for Unicode).  All ODBC functions that take
		// SQLPOINTER use count of bytes; all functions that take only
		// strings use count of characters.

		TRYODBC(hStmt,
			SQL_HANDLE_STMT,
			SQLBindCol(hStmt,
				iCol,
				SQL_C_TCHAR,
				(SQLPOINTER)pThisBinding->wszBuffer,
				(cchDisplay + 1) * sizeof(WCHAR),
				&pThisBinding->indPtr));


		// Now set the display size that we will use to display
		// the data.   Figure out the length of the column name

		TRYODBC(hStmt,
			SQL_HANDLE_STMT,
			SQLColAttribute(hStmt,
				iCol,
				SQL_DESC_NAME,
				NULL,
				0,
				&cchColumnNameLength,
				NULL));

		pThisBinding->cDisplaySize = max((SQLSMALLINT)cchDisplay, cchColumnNameLength);
		if (pThisBinding->cDisplaySize < NULL_SIZE)
			pThisBinding->cDisplaySize = NULL_SIZE;

		*pDisplay += pThisBinding->cDisplaySize + DISPLAY_FORMAT_EXTRA;

	}

	return;

Exit:

	exit(-1);

	return;
}


/************************************************************************
/* DisplayTitles: print the titles of all the columns and set the
/*                shell window's width
/*
/* Parameters:
/*      hStmt          Statement handle
/*      cDisplaySize   Total display size
/*      pBinding        list of binding information
/************************************************************************/

void DisplayTitles(HSTMT     hStmt,
	DWORD     cDisplaySize,
	BINDING* pBinding)
{
	WCHAR           wszTitle[DISPLAY_MAX];
	SQLSMALLINT     iCol = 1;

	SetConsole(cDisplaySize + 2, TRUE);

	for (; pBinding; pBinding = pBinding->sNext)
	{
		TRYODBC(hStmt,
			SQL_HANDLE_STMT,
			SQLColAttribute(hStmt,
				iCol++,
				SQL_DESC_NAME,
				wszTitle,
				sizeof(wszTitle), // Note count of bytes!
				NULL,
				NULL));

		wprintf(DISPLAY_FORMAT_C,
			PIPE,
			pBinding->cDisplaySize,
			pBinding->cDisplaySize,
			wszTitle);
	}

Exit:

	wprintf(L" %c", PIPE);
	SetConsole(cDisplaySize + 2, FALSE);
	wprintf(L"\n");

}


/************************************************************************
/* SetConsole: sets console display size and video mode
/*
/*  Parameters
/*      siDisplaySize   Console display size
/*      fInvert         Invert video?
/************************************************************************/

void SetConsole(DWORD dwDisplaySize,
	BOOL  fInvert)
{
	HANDLE                          hConsole;
	CONSOLE_SCREEN_BUFFER_INFO      csbInfo;

	// Reset the console screen buffer size if necessary

	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	if (hConsole != INVALID_HANDLE_VALUE)
	{
		if (GetConsoleScreenBufferInfo(hConsole, &csbInfo))
		{
			if (csbInfo.dwSize.X < (SHORT)dwDisplaySize)
			{
				csbInfo.dwSize.X = (SHORT)dwDisplaySize;
				SetConsoleScreenBufferSize(hConsole, csbInfo.dwSize);
			}

			gHeight = csbInfo.dwSize.Y;
		}

		if (fInvert)
		{
			SetConsoleTextAttribute(hConsole, (WORD)(csbInfo.wAttributes | BACKGROUND_BLUE));
		}
		else
		{
			SetConsoleTextAttribute(hConsole, (WORD)(csbInfo.wAttributes & ~(BACKGROUND_BLUE)));
		}
	}
}


/************************************************************************
/* HandleDiagnosticRecord : display error/warning information
/*
/* Parameters:
/*      hHandle     ODBC handle
/*      hType       Type of handle (HANDLE_STMT, HANDLE_ENV, HANDLE_DBC)
/*      RetCode     Return code of failing command
/************************************************************************/

void HandleDiagnosticRecord(SQLHANDLE      hHandle,
	SQLSMALLINT    hType,
	RETCODE        RetCode)
{
	SQLSMALLINT iRec = 0;
	SQLINTEGER  iError;
	WCHAR       wszMessage[1000];
	WCHAR       wszState[SQL_SQLSTATE_SIZE + 1];


	if (RetCode == SQL_INVALID_HANDLE)
	{
		fwprintf(stderr, L"Invalid handle!\n");
		return;
	}

	while (SQLGetDiagRec(hType,
		hHandle,
		++iRec,
		wszState,
		&iError,
		wszMessage,
		(SQLSMALLINT)(sizeof(wszMessage) / sizeof(WCHAR)),
		(SQLSMALLINT*)NULL) == SQL_SUCCESS)
	{
		// Hide data truncated..
		if (wcsncmp(wszState, L"01004", 5))
		{
			fwprintf(stderr, L"[%5.5s] %s (%d)\n", wszState, wszMessage, iError);
		}
	}

}
